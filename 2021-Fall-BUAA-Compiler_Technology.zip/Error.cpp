//
// Created by WYSJ6174 on 2021/9/24.
//

#include "Error.h"

void Error::alert() {
    cout << msg_ << endl;
}
